export default function SecretPage() {
  return <div>
    <h1>SecretPage</h1>
  </div>
}