import { useEffect, useState } from "react";

export default function useAsyncFn(fn, ...params) {
    const [result, setResult] = useState({
        pending: true,
        data: null,
        error: null,
    });

    useEffect(() => {
        let isMounted = true;

        (async () => {
            try {
                const data = await fn(...params);

                if (!isMounted) return;

                setResult({
                    pending: false,
                    data,
                    error: null,
                });
            } catch (error) {
                if (!isMounted) return;

                setResult({
                    pending: false,
                    data: null,
                    error,
                });
            }
        })();

        return () => {
            isMounted = false; // предотвращаем обновление состояния после размонтирования
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return result;
}
